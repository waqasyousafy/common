/*
 * Created on 2021-10-21 11:06:07 PM.
 * Copyright © 2021 刘振林. All rights reserved.
 */

package com.liuzhenlin.common.utils;

@FunctionalInterface
public interface Condition {
    boolean meets();
}
/*
 * Created on 2021-10-28 10:01:53 PM.
 * Copyright © 2021 刘振林. All rights reserved.
 */

package com.liuzhenlin.common.listener;

public interface OnBackPressedPreImeListener {
    boolean onBackPressedPreIme();
}

/*
 * Created on 2021-10-27 6:31:52 PM.
 * Copyright © 2021 刘振林. All rights reserved.
 */

package com.liuzhenlin.common.listener;

public interface OnWindowFocusChangedListener {
    void onWindowFocusChanged(boolean hasFocus);
}